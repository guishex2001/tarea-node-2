// Importar los módulos necesarios
const express = require('express');

// Crear una instancia de la aplicación Express
const app = express();

// Definir las rutas
app.get('/', (req, res) => {
  res.send('¡Hola, mundo!');
});

app.get('/saludo', (req, res) => {
  res.send('¡Hola! ¿Cómo estás?');
});

app.get('/despedida', (req, res) => {
  res.send('¡Hasta luego!');
});

// Configurar el puerto en el que se ejecutará el servidor
const PORT = process.env.PORT || 3000;

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`Servidor Express iniciado en el puerto ${PORT}`);
});

app.get('/saludo/:nombre', (req, res) => {
    const nombre = req.params.nombre;
    res.send(`¡Hola, ${nombre}!`);
  });
  